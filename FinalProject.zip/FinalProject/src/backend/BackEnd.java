package backend;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;

public class BackEnd {

	// JDBC variables
	private Connection conn = null;
	private Statement st = null;
	private PreparedStatement ps = null;
	private ResultSet rs = null;
	private ArrayList<String> request = null;
	private String response = null;
	private boolean result;

//	private String addUser = "insert into Userinfo(Username, HashedPassword) "
//			+ "select ifNULL(max(id),0)+1,?,? FROM Userinfo";

	public static ArrayList<String> getJsonString(String infile) {
		while (true) {
			FileReader fr = null;
			File file = null;
			try {
				ArrayList<String> info = new ArrayList<String>();
				JSONParser parser = new JSONParser();
				file = new File(infile);
				while (!file.canRead() || !file.canWrite()) {
				}
				fr = new FileReader(infile);
				JSONObject obj = (JSONObject) parser.parse(fr);
				String Type = (String) obj.get("Typename");
				if (fr != null) {
					fr.close();
					while (!file.canRead() || !file.canWrite()) {
					}
					System.out.println(file.delete());
				}
				if (Type.equals("Login")) {
					// String Operation = (String) obj.get("Operation");
					String Username = (String) obj.get("Username");
					String Password = (String) obj.get("Password");
					info.add("Login");
					// info.add(Operation);
					info.add(Username);
					info.add(Password);
					return info;
				} else if (Type.equals("Monsterjson")) {
//					String Operation = (String) obj.get("Operation");
//					String Monstername = (String) obj.get("Monstername");
//					String HP = (String) obj.get("HP");
//					String Attack = (String) obj.get("Attack");
//					info.add("Monster");
//					info.add(Operation);
//					info.add(Monstername);
//					info.add(HP);
//					info.add(Attack);
//					return info;
				} else if (Type.equals("Register")) {
					String Username = (String) obj.get("Username");
					String Password = (String) obj.get("Password");
					info.add("Register");
					info.add(Username);
					info.add(Password);
					return info;
				} else {
					info.add("Invalid");
					return info;
				}
			} catch (FileNotFoundException fnfe) {
				System.out.println("Waiting for the file.");
			} catch (IOException ioe) {
				System.out.println("Waiting for the file.");
			} catch (Exception poe) {
				System.out.println("Waiting for the file.");
			}
		}

	}

//	public static ArrayList<String> getJsonString(String infile) {
//		while (true) {
//			try {
//				ArrayList<String> info = new ArrayList<String>();
//				JSONParser parser = new JSONParser();
//				JSONObject obj = (JSONObject) parser.parse(new FileReader(infile));
//				String Type = (String) obj.get("Typename");
//				if (Type.equals("Login")) {
//					// String Operation = (String) obj.get("Operation");
//					String Username = (String) obj.get("Username");
//					String Password = (String) obj.get("Password");
//					info.add("Login");
//					// info.add(Operation);
//					info.add(Username);
//					info.add(Password);
//					return info;
//				} else if (Type.equals("Monsterjson")) {
////					String Operation = (String) obj.get("Operation");
////					String Monstername = (String) obj.get("Monstername");
////					String HP = (String) obj.get("HP");
////					String Attack = (String) obj.get("Attack");
////					info.add("Monster");
////					info.add(Operation);
////					info.add(Monstername);
////					info.add(HP);
////					info.add(Attack);
////					return info;
//				} else if (Type.equals("Register")) {
//					String Username = (String) obj.get("Username");
//					String Password = (String) obj.get("Password");
//					info.add("Register");
//					info.add(Username);
//					info.add(Password);
//					return info;
//				} else {
//					info.add("Invalid");
//					return info;
//				}
//			} catch (FileNotFoundException fnfe) {
//				System.out.println("Waiting for the file.");
//			} catch (IOException ioe) {
//				System.out.println("Waiting for the file.");
//			} catch (Exception poe) {
//				System.out.println("Waiting for the file.");
//			}
//		}
//
//	}

	private Boolean running() {
		while (true) {
			request = getJsonString("Passin.json");
			if (request.get(0) == "Register") {
				String username = request.get(1);
				String password = request.get(2);
				result = signUpUser(username, password);
			} else if (request.get(0) == "Login") {
				String username = request.get(1);
				String password = request.get(2);
				result = signInUser(username, password);
			}

			try {
				JSONObject obj = new JSONObject();
				obj.put("Result", result); // return boolean
				obj.put("Comment", response); // return String

				// try-with-resources statement based on post comment below :)
				FileWriter file = new FileWriter("Passout.json");
				try {
					file.write(obj.toJSONString());
					System.out.println("Successfully Copied JSON Object to File...");
					System.out.println("\nJSON Object: " + obj);
				} catch (IOException ie) {
					System.out.println("Output JSON ie: " + ie.getMessage());
				} finally {
					file.flush();
					file.close();
				}
			} catch (IOException ie) {
				System.out.println("JSON ie: " + ie.getMessage());
			}
		}
	}

	public BackEnd() { // have connection with MySQL
		try {
			Class.forName("com.mysql.jdbc.Driver");
			conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/Info?user=root&password=root&useSSL=false");
		} catch (SQLException sqle) {
			System.out.println("SQLException: " + sqle.getMessage());
		} catch (ClassNotFoundException cnfe) {
			System.out.println("ClassNotFoundException: " + cnfe.getMessage());
		}
	}

	public boolean signUpUser(String username, String password) { // Sign-Up a new user
		if (!this.findExistedUser(username)) {
			try {
				ps = conn.prepareStatement("insert into Userinfo(Username, HashedPassword) VALUES(?, ?)");
				ps.setString(1, username);
				ps.setString(2, password);
				ps.executeUpdate();
			} catch (SQLException sqle) {
				System.out.println("Sign-Up User Exception :" + sqle.toString());
			} finally {
				this.closeOperators();
			}
			response = "Sign-Up Successful";
			return true;
		} else {
			System.out.println("Error: Username has been used.");
			response = "Username has been used.";
			return false;
		}
	}

	public boolean findExistedUser(String username) { // check username existed
		boolean existed = false;
		try {
			st = conn.createStatement();
			rs = st.executeQuery("SELECT * FROM Userinfo WHERE Username='" + username + "';");
			while (rs.next()) {
				String uname = rs.getString("Username");
				if (uname.equals(username)) {
					existed = true;
					System.out.println("exists");
				}
			}
		} catch (SQLException sqle) {
			System.out.println("Sign-In User Exception: " + sqle.getMessage());
		} finally {
			this.closeOperators();
		}
		return existed;
	}

	public boolean signInUser(String username, String password) { // Sign-In the user account
		try {
			st = conn.createStatement();
			rs = st.executeQuery("SELECT * FROM Userinfo WHERE Username='" + username
					+ /* "' AND HashedPassword='" + password + */"';");
			// boolean checkSignIn = false;
			while (rs.next()) { // if or while
				ResultSet rs2 = st.executeQuery("SELECT * FROM Userinfo WHERE Username='" + username
						+ "' AND HashedPassword='" + password + "';");
				while (rs2.next()) {
					response = "Login Successful.";
					System.out.println("Login");
					return true;
				}
				response = "Password Incorrect.";
				System.out.println("Password Incorrect.");
				return false;
				// int userID = rs.getInt("SaveID");
				// String uname = rs.getString("Username");
				// String pword = rs.getString("HashedPassword");
				// System.out.println("UserID: " + userID + "\nUsername: " + uname +
				// "\nPassword: " + pword);
			}
			response = "Username does not exist.";
			System.out.println("Username does not exist.");
			/*
			 * System.out.println("Sign-In " + (checkSignIn ? "Suceesfully" : "Failed") +
			 * "."); if (!checkSignIn) { // if user provide the wrong password
			 * System.out.println("Wrong Password."); }
			 */
		} catch (SQLException sqle) {
			System.out.println("Sign-In User Exception: " + sqle.getMessage());
		} finally {
			this.closeOperators();
		}
		return false;
	}

	public void addMonster(String monstername, int hp, int attack) { // Add a monster to the market
		try {
			ps = conn.prepareStatement("insert into Monster(MonsterName, HP, Attack) VALUES(?, ?, ?)");
			ps.setString(1, monstername);
			ps.setInt(2, hp);
			ps.setInt(3, attack);
			ps.executeUpdate();
		} catch (SQLException sqle) {
			System.out.println("Add Monster Exception :" + sqle.toString());
		} finally {
			this.closeOperators();
		}
	}

	public void findMonster(String monstername, int hp, int attack) { // Find the monster
		try {
			st = conn.createStatement();
			rs = st.executeQuery("SELECT * FROM Monster WHERE MonsterName = '" + monstername + "' AND HP = '" + hp
					+ "' AND Attack = '" + attack + "';");
			boolean found = false;
			while (rs.next()) {
				int monsterID = rs.getInt("MonsterID");
				String mname = rs.getString("MonsterName");
				int hps = rs.getInt("HP");
				int atk = rs.getInt("Attack");
				// System.out.println(monsterID + " - " + mname + " " + hps);
				found = true;
			}
			System.out.println("Find Monster " + (found ? "Suceesfully" : "Failed") + ".");
		} catch (SQLException sqle) {
			System.out.println("Sign-In User Exception: " + sqle.getMessage());
		} finally {
			this.closeOperators();
		}
	}

	public void removeMonster(String monstername, int hp, int attack) { // Remove monster from market
		try {
			ps = conn.prepareStatement("DELETE * FROM Monster WHERE MonsterName = '" + monstername + "' AND HP = '" + hp
					+ "' AND Attack = '" + attack + "';");
			ps.executeUpdate();
		} catch (SQLException sqle) {
			System.out.println("Remove monster Exception :" + sqle.toString());
		} finally {
			this.closeOperators();
		}
	}

	private void closeOperators() {
		try {
			if (rs != null) {
				rs.close();
			}
			if (st != null) {
				st.close();
			}
			if (ps != null) {
				ps.close();
			}
		} catch (SQLException sqle) {
			System.out.println("sqle: " + sqle.getMessage());
		}
	}

	private void disconnectMySQL() {
		try {
			if (conn != null) {
				conn.close();
			}
		} catch (SQLException sqle) {
			System.out.println("Connection closing streams: " + sqle.getMessage());
		}
	}

	public static void main(String[] args) {
		/*
		 * ArrayList<String> request = getJsonString("Passin.json"); ArrayList<String>
		 * response = new ArrayList<String>();
		 * 
		 * // JDBC BackEnd database = new BackEnd();
		 * 
		 * if (request.get(0) == "User") { // User part String username =
		 * request.get(2); String password = request.get(3); if (request.get(1) ==
		 * "SignUp") { // Sign-up database.signUpUser(username, password); } else if
		 * (request.get(1) == "SignIn") { // Sign-in database.signInUser(username,
		 * password); } else { System.out.println("User operation is invalid."); } }
		 * else if (request.get(0) == "Monster") { // Monster part String monstername =
		 * request.get(2); int hp = Integer.parseInt(request.get(3)); int attack =
		 * Integer.parseInt(request.get(4)); if (request.get(1) == "Add") {
		 * database.addMonster(monstername, hp, attack); } else if (request.get(1) ==
		 * "Find") { database.findMonster(monstername, hp, attack); } else if
		 * (request.get(1) == "Remove") { database.removeMonster(monstername, hp,
		 * attack); } else { System.out.println("User operation is invalid."); } } else
		 * { System.out.println("request is invalid."); } database.disconnectMySQL();
		 */
		BackEnd database = new BackEnd();
		Boolean result = database.running();
	}
}
