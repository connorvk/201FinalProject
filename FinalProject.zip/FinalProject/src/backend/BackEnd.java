package backend;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import javax.lang.model.util.ElementScanner6;

import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;

public class BackEnd {

	public static void main(String[] args) {

		Thread database = new NormalThread();
		database.start();
		// database.running();
		// database.disconnectMySQL();
	}

}

class NormalThread extends Thread {

	private Connection conn = null;
	private Statement st = null;
	private PreparedStatement ps = null;
	private ResultSet rs = null;
	private ArrayList<String> request = null;
	private String response = null;
	private boolean result;
	private String loadinventory = null;

	public NormalThread() {
		try {
			Class.forName("com.mysql.jdbc.Driver");
			conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/Info?user=root&password=root&useSSL=false");
		} catch (SQLException sqle) {
			System.out.println("SQLException: " + sqle.getMessage());
		} catch (ClassNotFoundException cnfe) {
			System.out.println("ClassNotFoundException: " + cnfe.getMessage());
		}
	}

	/* Handle User Information */
	public boolean signUpUser(String username, String password, String userinventory) {
		if (!this.findExistedUser(username)) {
			try {
				ps = conn.prepareStatement("insert into Userinfo(Username, UserPassword) VALUES(?, ?)");
				ps.setString(1, username);
				ps.setString(2, password);
				ps.executeUpdate();
			} catch (SQLException sqle) {
				System.out.println("Sign-Up User Exception :" + sqle.toString());
			} finally {
				this.closeOperators();
			}
			if (saveInentory(username, userinventory)) {
				response = "Sign-Up Successful.";
				return true;
			}
			response = "Sign-Up Failed.";
			return false;
		}
		System.out.println("Error: Username has been used.");
		response = "Username has been used.";
		return false;
	}

	public boolean findExistedUser(String username) { // check if username exists
		boolean existed = false;
		try {
			st = conn.createStatement();
			rs = st.executeQuery("SELECT * FROM Userinfo WHERE Username='" + username + "';");
			while (rs.next()) {
				String uname = rs.getString("Username");
				if (uname.equals(username)) {
					existed = true;
					System.out.println("exists");
				}
			}
		} catch (SQLException sqle) {
			System.out.println("Sign-In User Exception: " + sqle.getMessage());
		} finally {
			this.closeOperators();
		}
		return existed;
	}

	public boolean signInUser(String username, String password) {
		try {
			st = conn.createStatement();
			rs = st.executeQuery("SELECT * FROM Userinfo WHERE Username='" + username + "';");
			while (rs.next()) {
				ResultSet rs2 = st.executeQuery("SELECT * FROM Userinfo WHERE Username='" + username
						+ "' AND UserPassword='" + password + "';");
				while (rs2.next()) {
					response = "Login Successful.";
					if (loadInventory(username)) {
						System.out.println("Login");
						return true;
					}
				}
				response = "Password Incorrect.";
				System.out.println("Password Incorrect.");
				return false;
			}
		} catch (SQLException sqle) {
			System.out.println("Sign-In User Exception: " + sqle.getMessage());
		} finally {
			this.closeOperators();
		}
		response = "Username does not exist.";
		System.out.println("Username does not exist.");
		return false;
	}

	/* Inventory Info */
	public boolean saveInentory(String username, String userinventory) {
		if (this.findExistedUser(username)) {
			try {
				ps = conn.prepareStatement("insert into Inventory(Username, Userinventory) VALUES(?, ?)");
				ps.setString(1, username);
				ps.setString(2, userinventory);
				ps.executeUpdate();
			} catch (SQLException sqle) {
				System.out.println("Save Inventory Exception :" + sqle.toString());
			} finally {
				this.closeOperators();
			}
			response = "Save " + username + "'s inventory Successful.";
			System.out.println("Save " + username + "'s inventory Successful.");
			return true;
		}
		response = "Save " + username + "'s inventory Failed.";
		System.out.println("Save " + username + "'s inventory Failed.");
		return false;
	}

	public boolean loadInventory(String username) { // find in inventory
		try {
			st = conn.createStatement();
			rs = st.executeQuery("SELECT * FROM Inventory WHERE Username = '" + username + "';");
			while (rs.next()) {
				loadinventory = rs.getString("Userinventory");
				response = "Load " + username + "'s inventory Successful.";
				System.out.println("Load " + username + "'s inventory Successful.");
				return true;
			}
		} catch (SQLException sqle) {
			System.out.println("Load Inventory Exception: " + sqle.getMessage());
		} finally {
			this.closeOperators();
		}
		response = "Load " + username + "'s inventory Failed.";
		System.out.println("Load " + username + "'s inventory Failed.");
		return false;
	}

	/* Market Info */
	public boolean sellMonster(String uname, String mname, String ask, int hp, int attack) {
		try {
			ps = conn.prepareStatement(
					"insert into Market(Username, Monstername, Ask, HP, Attack) VALUES(?, ?, ?, ?, ?)");
			ps.setString(1, uname);
			ps.setString(2, mname);
			ps.setString(3, ask);
			ps.setInt(4, hp);
			ps.setInt(5, attack);
			ps.executeUpdate();
			response = "Sell Successful.";
			System.out.println("Sell Successful.");
			return true;
		} catch (SQLException sqle) {
			System.out.println("Sell Monster to Market Exception :" + sqle.toString());
		} finally {
			this.closeOperators();
		}
		response = "Sell Failed.";
		System.out.println("Sell Failed.");
		return false;
	}

	public boolean tradeMonster(String uname, String mname, String ask, int hp, int attack) {
		try {
			rs = st.executeQuery("DELETE * FROM Market WHERE Username = '" + uname + "' AND MonsterName = '" + mname
					+ "' AND Ask = '" + ask + "' AND HP = '" + hp + "' AND Attack = '" + attack + "';");
			ps.executeUpdate();
			response = "Remove Successful.";
			System.out.println("Remove Successful.");
			return true;
		} catch (SQLException sqle) {
			System.out.println("Remove Monster Exception :" + sqle.toString());
		} finally {
			this.closeOperators();
		}
		response = "Remove Failed.";
		System.out.println("Remove Failed.");
		return false;
	}

	public boolean SearchMonster(String uname, String mname, String ask, int hp, int attack) { // find in inventory
		try {
			st = conn.createStatement();
			rs = st.executeQuery("SELECT * FROM Market WHERE Username = '" + uname + "' AND MonsterName = '" + mname
					+ "' AND Ask = '" + ask + "' AND HP = '" + hp + "' AND Attack = '" + attack + "';");
			while (rs.next()) {
				response = "Find Successful.";
				System.out.println("Find Successful.");
				return true;
			}
		} catch (SQLException sqle) {
			System.out.println("Find Monster Exception: " + sqle.getMessage());
		} finally {
			this.closeOperators();
		}
		response = "Find Failed.";
		System.out.println("Find Failed.");
		return false;
	}

	private void closeOperators() {
		try {
			if (rs != null) {
				rs.close();
			}
			if (st != null) {
				st.close();
			}
			if (ps != null) {
				ps.close();
			}
		} catch (SQLException sqle) {
			System.out.println("sqle: " + sqle.getMessage());
		}
	}

//	private void disconnectMySQL() {
//		try {
//			if (conn != null) {
//				conn.close();
//			}
//		} catch (SQLException sqle) {
//			System.out.println("Connection closing streams: " + sqle.getMessage());
//		}
//	}

	public static ArrayList<String> getJsonString(String infile) {

		while (true) {
			FileReader fr = null;
			File file = null;
			try {
				ArrayList<String> info = new ArrayList<String>();
				JSONParser parser = new JSONParser();
				file = new File(infile);
				while (!file.canRead() || !file.canWrite()) {
				}
				fr = new FileReader(infile);
				JSONObject obj = (JSONObject) parser.parse(fr);
				String Type = (String) obj.get("Typename");
				if (fr != null) {
					fr.close();
					while (!file.canRead() || !file.canWrite()) {
					}
					System.out.println(file.delete());
				}

				/* handle user info */
				if (Type.equals("Register")) { /* handle user info */
					String Username = (String) obj.get("Username");
					String Password = (String) obj.get("Password");
					String userinventory = (String) obj.get("Userinventory");
					info.add("Register");
					info.add(Username);
					info.add(Password);
					info.add(userinventory);
					return info;
				} else if (Type.equals("Login")) {
					String Username = (String) obj.get("Username");
					String Password = (String) obj.get("Password");
					info.add("Login");
					info.add(Username);
					info.add(Password);
					return info;
				} /* handle market */
				else if (Type.equals("Sell")) {

					return info;
				} else if (Type.equals("Trade")) {

					return info;
				} else if (Type.equals("Search")) {
					return info;
				} else {
					info.add("Invalid");
					return info;
				}
			} catch (FileNotFoundException fnfe) {
				System.out.println(fnfe);
			} catch (IOException ioe) {
				System.out.println(ioe);
			} catch (Exception poe) {
				System.out.println(poe);
			}
		}
	}

	public void run() {

		while (true) {
			request = getJsonString("Passin.json");
			if (request.get(0) == "Register") {
				String username = request.get(1);
				String password = request.get(2);
				String userinventory = request.get(3);
				result = signUpUser(username, password, userinventory);
			} else if (request.get(0) == "Login") {
				String username = request.get(1);
				String password = request.get(2);
				result = signInUser(username, password);
			} else if (request.get(0) == "Add") {
				System.out.println(request.get(1));
				String username = request.get(1);
				String monstername = request.get(2);
				int hp = Integer.parseInt(request.get(3));
				int attack = Integer.parseInt(request.get(4));
				// result = addMonster(username, monstername, hp, attack);
			} else if (request.get(0) == "Trade") {

				result = false;
			} else if (request.get(0) == "Search") {

			}

			try {
				JSONObject obj = new JSONObject();
				obj.put("Result", result); // return boolean
				obj.put("Comment", response); // return String
				if (request.get(0) == "Login")
					obj.put("Userinventory", loadinventory);

				// try-with-resources statement based on post comment below :)
				FileWriter file = new FileWriter("Passout.json");
				try {
					file.write(obj.toJSONString());
					System.out.println("Successfully Copied JSON Object to File...");
					System.out.println("\nJSON Object: " + obj);
				} catch (IOException ie) {
					System.out.println("Output JSON ie: " + ie.getMessage());
				} finally {
					file.flush();
					file.close();
				}
			} catch (IOException ie) {
				System.out.println("JSON ie: " + ie.getMessage());
			}
		}
	}
}

//class saveThread extends Thread {
//	private Connection conn = null;
//	private Statement st = null;
//	private PreparedStatement ps = null;
//	private ResultSet rs = null;
//	private ArrayList<String> request = null;
//	private String response = null;
//	private boolean result;
//	private String inventoryString = null;
//
//	public saveThread() {
//		try {
//			Class.forName("com.mysql.jdbc.Driver");
//			conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/Info?user=root&password=root&useSSL=false");
//		} catch (SQLException sqle) {
//			System.out.println("SQLException: " + sqle.getMessage());
//		} catch (ClassNotFoundException cnfe) {
//			System.out.println("ClassNotFoundException: " + cnfe.getMessage());
//		}
//	}
//	
//	public static ArrayList<String> getJsonString(String infile) {
//		while (true) {
//			FileReader fr = null;
//			File file = null;
//			try {
//				ArrayList<String> info = new ArrayList<String>();
//				JSONParser parser = new JSONParser();
//				file = new File(infile);
//				while (!file.canRead() || !file.canWrite()) {
//				}
//				fr = new FileReader(infile);
//				JSONObject obj = (JSONObject) parser.parse(fr);
//				String Type = (String) obj.get("Typename");
//				if (fr != null) {
//					fr.close();
//					while (!file.canRead() || !file.canWrite()) {
//					}
//					System.out.println(file.delete());
//				}
//
//				/* handle user info */
//				if (Type.equals("Register") || Type.equals("Login")) { /* handle user info */
//					String Username = (String) obj.get("Username");
//					String Password = (String) obj.get("Password");
//					info.add(Type.equals("Register") ? "Register" : "Login");
//					info.add(Username);
//					info.add(Password);
//					return info;
//				} /* handle inventory */
//				else if (Type.equals("Add") || Type.equals("Find") || Type.equals("Remove")) {
//					String Username = (String) obj.get("Username");
//					String Monstername = (String) obj.get("Monstername");
//					String hp = Long.toString((long) obj.get("HP"));
//					String attack = Long.toString((long) obj.get("Attack"));
//					if (Type.equals("Add"))
//						info.add("Add");
//					else if (Type.equals("Find"))
//						info.add("Find");
//					else
//						info.add("Remove");
//					info.add(Username);
//					info.add(Monstername);
//					info.add(hp);
//					info.add(attack);
//					return info;
//				} /* handle market */
//				else if (Type.equals("Sell")) {
//					String Username = (String) obj.get("Username");
//					String Monstername = (String) obj.get("Monstername");
//					String ask = (String) obj.get("Ask");
//					String hp = (String) obj.get("HP");
//					String attack = (String) obj.get("Attack");
//					info.add("Sell");
//					info.add(Username);
//					info.add(Monstername);
//					info.add(ask);
//					info.add(hp);
//					info.add(attack);
//					return info;
//				} else if(Type.equals("Save")) {
//					String username = (String) obj.get("Username");
//					String userinven = (String) obj.get("Userinventory");
//					info.add("Save");
//					info.add(username);
//					info.add(userinven);
//					return info;
//				}else {
//					info.add("Invalid");
//					return info;
//				}
//			} catch (FileNotFoundException fnfe) {
//				System.out.println(fnfe);
//			} catch (IOException ioe) {
//				System.out.println(ioe);
//			} catch (Exception poe) {
//				System.out.println(poe);
//			}
//		}
//	}
//
//	public void run() {
//		while (true) {
//			try {
//				st = conn.createStatement();
//				String sql = "SELECT Username FROM Userinfo;";
//				rs = st.executeQuery(sql);
//				while(rs.next()) {
//					String filename = rs.getString(1);
//					request = getJsonString(filename+".json");
//				}
//				String username = request.get(1);
//				String invenjson = request.get(2);
//				sql = "insert into Inventory(Username, Userinventory) VALUES(?, ?)";
//				ps = conn.prepareStatement(sql);
//				//ps.setString(2, x);
//				
//			}catch(Exception exp) {
//				
//			}
//			
//			
//		}
//	}
//}