package backend;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;

import com.google.gson.internal.bind.TreeTypeAdapter;

public class BackEnd {

	public static void main(String[] args) {
		Thread database = new NormalThread();
		database.start();
		Thread saveDatabase = new saveThread();
		saveDatabase.start();
	}

}

class NormalThread extends Thread {

	private Connection conn = null;
	private Statement st = null;
	private PreparedStatement ps = null;
	private ResultSet rs = null;
	private ArrayList<String> request = null;
	private String response = null;
	private boolean result;
	private String loadinventory = null;
	private String saveBuyer = null;
	private String saveSeller = null;
	private String saveMonster = null;
	private String saveAsk = null;

	private ArrayList<String> mUsername = new ArrayList<String>();
	private ArrayList<String> mMonstername = new ArrayList<String>();
	private ArrayList<String> mAsk = new ArrayList<String>();
	private ArrayList<Integer> mID = new ArrayList<Integer>();
	private ArrayList<Integer> mHP = new ArrayList<Integer>();
	private ArrayList<Integer> mAttack = new ArrayList<Integer>();

	public NormalThread() {
		try {
			Class.forName("com.mysql.jdbc.Driver");
			conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/Info?user=root&password=root&useSSL=false");
		} catch (SQLException sqle) {
			System.out.println("SQLException: " + sqle.getMessage());
		} catch (ClassNotFoundException cnfe) {
			System.out.println("ClassNotFoundException: " + cnfe.getMessage());
		}
	}

	/* Handle User Information */
	public boolean signUpUser(String username, String password, String userinventory) {
		if (!this.findExistedUser(username)) {
			try {
				ps = conn.prepareStatement("insert into Userinfo(Username, UserPassword) VALUES(?, ?)");
				ps.setString(1, username);
				ps.setString(2, password);
				ps.executeUpdate();
			} catch (SQLException sqle) {
				System.out.println("Sign-Up User Exception :" + sqle.toString());
			} finally {
				this.closeOperators();
			}
			if (saveInentory(username, userinventory)) {
				response = "Sign-Up Successful.";
				return true;
			}
			response = "Sign-Up Failed.";
			return false;
		}
		System.out.println("Error: Username has been used.");
		response = "Username has been used.";
		return false;
	}

	public boolean findExistedUser(String username) { // check if username exists
		boolean existed = false;
		try {
			st = conn.createStatement();
			rs = st.executeQuery("SELECT * FROM Userinfo WHERE Username='" + username + "';");
			while (rs.next()) {
				String uname = rs.getString("Username");
				if (uname.equals(username))
					existed = true;
			}
		} catch (SQLException sqle) {
			System.out.println("Sign-In User Exception: " + sqle.getMessage());
		} finally {
			this.closeOperators();
		}
		return existed;
	}

	public boolean signInUser(String username, String password) {
		try {
			st = conn.createStatement();
			rs = st.executeQuery("SELECT * FROM Userinfo WHERE Username='" + username + "';");
			while (rs.next()) {
				ResultSet rs2 = st.executeQuery("SELECT * FROM Userinfo WHERE Username='" + username
						+ "' AND UserPassword='" + password + "';");
				while (rs2.next()) {
					response = "Login Successful.";
					if (loadInventory(username)) {
						System.out.println("Login");
						return true;
					}
				}
				response = "Password Incorrect.";
				System.out.println("Password Incorrect.");
				return false;
			}
		} catch (SQLException sqle) {
			System.out.println("Sign-In User Exception: " + sqle.getMessage());
		} finally {
			this.closeOperators();
		}
		response = "Username does not exist.";
		System.out.println("Username does not exist.");
		return false;
	}

	/* Inventory Info */
	public boolean saveInentory(String username, String userinventory) {
		if (this.findExistedUser(username)) {
			try {
				ps = conn.prepareStatement("insert into Inventory(Username, Userinventory) VALUES(?, ?)");
				ps.setString(1, username);
				ps.setString(2, userinventory);
				ps.executeUpdate();
			} catch (SQLException sqle) {
				System.out.println("Save Inventory Exception :" + sqle.toString());
			} finally {
				this.closeOperators();
			}
			response = "Save " + username + "'s inventory Successful.";
			System.out.println("Save " + username + "'s inventory Successful.");
			return true;
		}
		response = "Save " + username + "'s inventory Failed.";
		System.out.println("Save " + username + "'s inventory Failed.");
		return false;
	}

	public boolean loadInventory(String username) { // find in inventory
		try {
			st = conn.createStatement();
			rs = st.executeQuery("SELECT * FROM Inventory WHERE Username = '" + username + "';");
			while (rs.next()) {
				loadinventory = rs.getString("Userinventory");
				response = "Load " + username + "'s inventory Successful.";
				System.out.println("Load " + username + "'s inventory Successful.");
				return true;
			}
		} catch (SQLException sqle) {
			System.out.println("Load Inventory Exception: " + sqle.getMessage());
		} finally {
			this.closeOperators();
		}
		response = "Load " + username + "'s inventory Failed.";
		System.out.println("Load " + username + "'s inventory Failed.");
		return false;
	}

	/* Market Info */
	public boolean sellMonster(String uname, String mname, String ask, int hp, int attack) {
		try {
			ps = conn.prepareStatement(
					"insert into Market(Username, Monstername, Ask, HP, Attack) VALUES(?, ?, ?, ?, ?)");
			ps.setString(1, uname);
			ps.setString(2, mname);
			ps.setString(3, ask);
			ps.setInt(4, hp);
			ps.setInt(5, attack);
			ps.executeUpdate();
			response = "Sell Successful.";
			System.out.println("Sell Successful.");
			return true;
		} catch (SQLException sqle) {
			System.out.println("Sell Monster to Market Exception :" + sqle.toString());
		} finally {
			this.closeOperators();
		}
		response = "Sell Failed.";
		System.out.println("Sell Failed.");
		return false;
	}

	public boolean tradeMonster(String buyer, String seller, String monster, String ask) {
		if (findMonster(seller, monster, ask)) {
			if (removeMonster(seller, monster, ask)) {
				response = "Trade Successful.";
				System.out.println("Trade Successful.");
				return true;
			}
			return false;
		}
		response = "Cannot find this monster in Market. Trade Failed.";
		System.out.println("Cannot find this monster in Market. Trade Failed.");
		return false;
	}

	public boolean findMonster(String uname, String mname, String ask) { // find in Market
		try {
			st = conn.createStatement();
			rs = st.executeQuery("SELECT * FROM Market WHERE Username = '" + uname + "' AND Monstername = '" + mname
					+ "' AND Ask = '" + ask + "';");
			while (rs.next()) {
				response = "Find Monster Successful.";
				System.out.println("Find Monster Successful.");
				return true;
			}
		} catch (SQLException sqle) {
			System.out.println("Find Monster Exception: " + sqle.getMessage());
		} finally {
			this.closeOperators();
		}
		response = "Find Monster Failed.";
		System.out.println("Find Monster Failed.");
		return false;
	}

	public boolean removeMonster(String uname, String mname, String ask) {
		try {
			String cmd = "DELETE FROM Market WHERE Username = ? AND Monstername = ? AND Ask = ?";
			ps = conn.prepareStatement(cmd);
			ps.setString(1, uname);
			ps.setString(2, mname);
			ps.setString(3, ask);
			ps.executeUpdate();
			response = "Remove Successful.";
			System.out.println("Remove Successful.");
			return true;
		} catch (SQLException sqle) {
			System.out.println("Remove Monster Exception: " + sqle.getMessage());
		} finally {
			this.closeOperators();
		}
		response = "Remove Failed.";
		System.out.println("Remove");
		return false;
	}

	public boolean loadMarket() {
		try {
			st = conn.createStatement();
			rs = st.executeQuery("SELECT * FROM Market");
			while (rs.next()) {
				String mU = rs.getString("Username");
				String mM = rs.getString("Monstername");
				String mA = rs.getString("Ask");
				int mI = rs.getInt("MonsterID");
				int mH = rs.getInt("HP");
				int mATK = rs.getInt("Attack");
				mUsername.add(mU);
				mMonstername.add(mM);
				mAsk.add(mA);
				mID.add(mI);
				mHP.add(mH);
				mAttack.add(mATK);
			}
			response = "Load Market Successful.";
			System.out.println("Load Market Successful.");
			return true;
		} catch (SQLException sqle) {
			System.out.println("Load Market Exception: " + sqle.getMessage());
		} finally {
			this.closeOperators();
		}
		response = "Load Market Failed.";
		System.out.println("Load Market Failed.");
		return false;
	}

	private void closeOperators() {
		try {
			if (rs != null) {
				rs.close();
			}
			if (st != null) {
				st.close();
			}
			if (ps != null) {
				ps.close();
			}
		} catch (SQLException sqle) {
			System.out.println("sqle: " + sqle.getMessage());
		}
	}

//	private void disconnectMySQL() {
//		try {
//			if (conn != null) {
//				conn.close();
//			}
//		} catch (SQLException sqle) {
//			System.out.println("Connection closing streams: " + sqle.getMessage());
//		}
//	}

	public static ArrayList<String> getJsonString(String infile) {

		while (true) {
			FileReader fr = null;
			File file = null;
			try {
				ArrayList<String> info = new ArrayList<String>();
				JSONParser parser = new JSONParser();
				file = new File(infile);
				while (!file.canRead() || !file.canWrite()) {
				}
				fr = new FileReader(infile);
				JSONObject obj = (JSONObject) parser.parse(fr);
				String Type = (String) obj.get("Typename");
				if (fr != null) {
					fr.close();
					while (!file.canRead() || !file.canWrite()) {
					}
					System.out.println(file.delete());
				}

				/* handle user info */
				if (Type.equals("Register")) { /* handle user info */
					String Username = (String) obj.get("Username");
					String Password = (String) obj.get("Password");
					String userinventory = (String) obj.get("Userinventory");
					info.add("Register");
					info.add(Username);
					info.add(Password);
					info.add(userinventory);
					return info;
				} else if (Type.equals("Login")) {
					String Username = (String) obj.get("Username");
					String Password = (String) obj.get("Password");
					info.add("Login");
					info.add(Username);
					info.add(Password);
					return info;
				} /* handle market */
				else if (Type.equals("Sell")) {
					String Username = (String) obj.get("Username");
					String monstername = (String) obj.get("Monstername");
					String ask = (String) obj.get("Ask");
					String hp = Long.toString((long) obj.get("HP"));
					String attack = Long.toString((long) obj.get("Attack"));
					info.add("Sell");
					info.add(Username);
					info.add(monstername);
					info.add(ask);
					info.add(hp);
					info.add(attack);
					return info;
				} else if (Type.equals("Remove")) {
					String Username = (String) obj.get("Username");
					String monstername = (String) obj.get("Monstername");
					String ask = (String) obj.get("Ask");
					info.add("Remove");
					info.add(Username);
					info.add(monstername);
					info.add(ask);
					return info;
				} else if (Type.equals("Trade")) {
					String buyer = (String) obj.get("Buyer");
					String seller = (String) obj.get("Seller");
					String monster = (String) obj.get("Monster");
					String ask = (String) obj.get("Ask");
					info.add("Trade");
					info.add(buyer);
					info.add(seller);
					info.add(monster);
					info.add(ask);
					return info;
				} else if (Type.equals("Find")) {
					String seller = (String) obj.get("Seller");
					String monster = (String) obj.get("Monster");
					String ask = (String) obj.get("Ask");
					info.add("Find");
					info.add(seller);
					info.add(monster);
					info.add(ask);
					return info;
				} else if (Type.equals("LoadMarket")) {
					info.add("LoadMarket");
					return info;
				} else {
					info.add("Invalid");
					return info;
				}
			} catch (FileNotFoundException fnfe) {
				System.out.println(fnfe);
			} catch (IOException ioe) {
				System.out.println(ioe);
			} catch (Exception poe) {
				System.out.println(poe);
			}
		}
	}

	public void run() {
		while (true) {
			request = getJsonString("Passin.json");
			if (request.get(0) == "Register") {
				String username = request.get(1);
				String password = request.get(2);
				String userinventory = request.get(3);
				result = signUpUser(username, password, userinventory);
			} else if (request.get(0) == "Login") {
				String username = request.get(1);
				String password = request.get(2);
				result = signInUser(username, password);
			} else if (request.get(0) == "Sell") {
				String username = request.get(1);
				String monstername = request.get(2);
				String ask = request.get(3);
				int hp = Integer.parseInt(request.get(4));
				int attack = Integer.parseInt(request.get(5));
				result = sellMonster(username, monstername, ask, hp, attack);
			} else if (request.get(0) == "Remove") {
				String username = request.get(1);
				String monstername = request.get(2);
				String ask = request.get(3);
				result = removeMonster(username, monstername, ask);
			} else if (request.get(0) == "Trade") {
				String buyer = request.get(1);
				String seller = request.get(2);
				String monster = request.get(3);
				String ask = request.get(4);
				saveBuyer = buyer;
				saveSeller = seller;
				saveMonster = monster;
				saveAsk = ask;
				result = tradeMonster(buyer, seller, monster, ask);
			} else if (request.get(0) == "Find") {
				String seller = request.get(1);
				String monster = request.get(2);
				String ask = request.get(3);
				result = findMonster(seller, monster, ask);
			} else if (request.get(0) == "LoadMarket") {
				result = loadMarket();
			}

			try {
				JSONObject obj = new JSONObject();
				obj.put("Result", result); // return boolean
				obj.put("Comment", response); // return String
				if (request.get(0) == "Login") {
					obj.put("Userinventory", loadinventory);
					loadinventory = null;
				} else if (request.get(0) == "Trade") {
					obj.put("Type", "TradingResult");
					obj.put("Buyer", saveBuyer);
					obj.put("Seller", saveSeller);
					obj.put("Monster", saveMonster);
					obj.put("Ask", saveAsk);
					saveBuyer = null;
					saveSeller = null;
					saveMonster = null;
					saveAsk = null;
				} else if (request.get(0) == "LoadMarket") {
					obj.put("Type", "LoadingMarket");
					for (int i = 0; i < mID.size(); i++) {
						JSONObject monsterlist = new JSONObject();
						monsterlist.put("MonsterID", mID.get(i));
						monsterlist.put("Seller", mUsername.get(i));
						monsterlist.put("Monster", mMonstername.get(i));
						monsterlist.put("Ask", mAsk.get(i));
						monsterlist.put("HP", mHP.get(i));
						monsterlist.put("Attack", mAttack.get(i));
						obj.put("Monster List " + (i + 1), monsterlist);
					}
					mID.clear();
					mUsername.clear();
					mMonstername.clear();
					mAsk.clear();
					mHP.clear();
					mAttack.clear();
				}

				// try-with-resources statement based on post comment below :)
				FileWriter file = new FileWriter("Passout.json");
				try {
					file.write(obj.toJSONString());
					System.out.println("Successfully Copied JSON Object to File...");
					System.out.println("\nJSON Object: " + obj);
				} catch (IOException ie) {
					System.out.println("Output JSON ie: " + ie.getMessage());
				} finally {
					file.flush();
					file.close();
				}
			} catch (IOException ie) {
				System.out.println("JSON ie: " + ie.getMessage());
			}
		}
	}
}

class saveThread extends Thread {

	private Connection conn = null;
	private Statement st = null;
	private PreparedStatement ps = null;
	private ResultSet rs = null;
	private ArrayList<String> request = null;
	private String response = null;
	private boolean result;

	public saveThread() {
		try {
			Class.forName("com.mysql.jdbc.Driver");
			conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/Info?user=root&password=root&useSSL=false");
		} catch (SQLException sqle) {
			System.out.println("SQLException: " + sqle.getMessage());
		} catch (ClassNotFoundException cnfe) {
			System.out.println("ClassNotFoundException: " + cnfe.getMessage());
		}
	}

	/* handle save Inventroy */
	public boolean saveInventory(String username, String userinventory) {
		if (findExistedUser(username)) {
			try {
				st = conn.createStatement();
				st.executeQuery("UPDATE Inventory SET Userinventory = '" + userinventory + "' WHERE Username = '"
						+ username + "';");
				response = "Save Inventory Successful.";
				System.out.println("Save Inventory Successful.");
				return true;
			} catch (SQLException sqle) {
				System.out.println("Save Inventory Exception: " + sqle.getMessage());
			} finally {
				this.closeOperators();
			}
			response = "Save Inventory Failed.";
			System.out.println("Save Inventory Failed.");
			return false;
		}
		response = "Cannot find " + username + " in inventory.";
		System.out.println("Cannot find " + username + " in inventory.");
		return false;
	}

	public boolean findExistedUser(String username) { // check if username exists
		boolean existed = false;
		try {
			st = conn.createStatement();
			rs = st.executeQuery("SELECT * FROM Inventory WHERE Username='" + username + "';");
			while (rs.next()) {
				String uname = rs.getString("Username");
				if (uname.equals(username))
					existed = true;
			}
		} catch (SQLException sqle) {
			System.out.println("Sign-In User Exception: " + sqle.getMessage());
		} finally {
			this.closeOperators();
		}
		return existed;
	}

	private void closeOperators() {
		try {
			if (rs != null) {
				rs.close();
			}
			if (st != null) {
				st.close();
			}
			if (ps != null) {
				ps.close();
			}
		} catch (SQLException sqle) {
			System.out.println("sqle: " + sqle.getMessage());
		}
	}

	public static ArrayList<String> getJsonString(String infile) {
		while (true) {
			FileReader fr = null;
			File file = null;
			try {
				ArrayList<String> info = new ArrayList<String>();
				JSONParser parser = new JSONParser();
				file = new File(infile);
				while (!file.canRead() || !file.canWrite()) {
				}
				fr = new FileReader(infile);
				JSONObject obj = (JSONObject) parser.parse(fr);
				String Type = (String) obj.get("Typename");
				if (fr != null) {
					fr.close();
					while (!file.canRead() || !file.canWrite()) {
					}
					System.out.println(file.delete());
				}

				/* handle save function */
				if (Type.equals("Save")) {
					String username = (String) obj.get("Username");
					String userinventory = (String) obj.get("Userinventory");
					info.add("Save");
					info.add(username);
					info.add(userinventory);
					return info;
				} else {
					info.add("Invalid");
					return info;
				}

			} catch (FileNotFoundException fnfe) {
				System.out.println(fnfe);
			} catch (IOException ioe) {
				System.out.println(ioe);
			} catch (Exception poe) {
				System.out.println(poe);
			}
		}
	}

	public void run() {
		while (true) {
			try {
				st = conn.createStatement();
				String sql = "SELECT Username FROM Userinfo;";
				rs = st.executeQuery(sql);
				while (rs.next()) {
					String filename = rs.getString(1);
					String testd = filename + ".josn";
					request = getJsonString(testd);
				}
			} catch (SQLException sqle) {
				System.out.println("Sign-In User Exception: " + sqle.getMessage());
			} finally {
				this.closeOperators();
			}
//			request = getJsonString("Vincent.json");

			if (request.get(0) == "Save") {
				String username = request.get(1);
				String userinventory = request.get(2);
				result = saveInventory(username, userinventory);
			}

			try {
				JSONObject obj = new JSONObject();
				obj.put("Result", result); // return boolean
				obj.put("Comment", response); // return String

				// try-with-resources statement based on post comment below :)
				FileWriter file = new FileWriter("Passout.json");
				try {
					file.write(obj.toJSONString());
					System.out.println("Successfully Copied JSON Object to File...");
					System.out.println("\nJSON Object: " + obj);
				} catch (IOException ie) {
					System.out.println("Output JSON ie: " + ie.getMessage());
				} finally {
					file.flush();
					file.close();
				}
			} catch (IOException ie) {
				System.out.println("JSON ie: " + ie.getMessage());
			}
		}
	}
}